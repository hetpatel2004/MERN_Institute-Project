import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Building2,
  BookOpen,
  BriefcaseBusiness,
  ShieldCheck,
  Users,
  GraduationCap,
  Plus,
  TrendingUp,
  LogOut,
} from "lucide-react";

import "./Supper_admin.css";

import Institutes from "./Institutes";
import Courses from "./AdminCourses";
import Companies from "./Companies";

function Dashboard({ institutes, courses, companies, navigate }) {
  const totalStudents = institutes.reduce(
    (total, item) => total + Number(item.students || 0),
    0
  );

  return (
    <>
      <div className="sa-header">
        <div>
          <p className="sa-tag">MULTI INSTITUTE MANAGEMENT</p>
          <h1>Super Admin Dashboard</h1>
          <span>Manage your whole platform from one place</span>
        </div>

        <button
          className="sa-primary-btn"
          onClick={() => navigate("/superadmin/institutes")}
        >
          <Plus size={20} />
          Add Institute
        </button>
      </div>

      <div className="sa-stats">
        <div className="sa-stat-card">
          <Building2 size={32} />
          <p>Total Institutes</p>
          <h2>{institutes.length}</h2>
          <span>Active partners</span>
        </div>

        <div className="sa-stat-card">
          <Users size={32} />
          <p>Total Students</p>
          <h2>{totalStudents}</h2>
          <span>All institutes</span>
        </div>

        <div className="sa-stat-card">
          <GraduationCap size={32} />
          <p>Total Courses</p>
          <h2>{courses.length}</h2>
          <span>Course modules</span>
        </div>

        <div className="sa-stat-card">
          <BriefcaseBusiness size={32} />
          <p>Companies</p>
          <h2>{companies.length}</h2>
          <span>Placement partners</span>
        </div>
      </div>

      <div className="sa-dashboard-grid">
        <div className="sa-hero">
          <p>COMMAND CENTER</p>
          <h2>Control your education platform easily.</h2>
          <span>
            Manage institutes, courses, companies, students and placement
            activity from this super admin dashboard.
          </span>
        </div>

        <div className="sa-module-card">
          <h3>Website Overview</h3>

          <div className="sa-module-row">
            <span>Institute Management</span>
            <b>{institutes.length}</b>
          </div>

          <div className="sa-module-row">
            <span>Course Management</span>
            <b>{courses.length}</b>
          </div>

          <div className="sa-module-row">
            <span>Placement Companies</span>
            <b>{companies.length}</b>
          </div>

          <div className="sa-module-row">
            <span>Growth Rate</span>
            <b>
              <TrendingUp size={18} /> 86%
            </b>
          </div>
        </div>
      </div>
    </>
  );
}

function Supper_admin() {
  const navigate = useNavigate();
  const location = useLocation();

  const [institutes, setInstitutes] = useState([
    {
      id: 1,
      name: "Frameboxx Institute",
      city: "Ahmedabad",
      admin: "Raj Patel",
      students: 320,
      status: "Active",
    },
    {
      id: 2,
      name: "Tech Skill Academy",
      city: "Surat",
      admin: "Mehul Shah",
      students: 210,
      status: "Active",
    },
  ]);

  const [courses, setCourses] = useState([
    {
      id: 1,
      name: "Full Stack Development",
      type: "IT Course",
      duration: "6 Months",
      fees: "45000",
    },
    {
      id: 2,
      name: "Cyber Security",
      type: "Security Course",
      duration: "8 Months",
      fees: "60000",
    },
  ]);

  const [companies, setCompanies] = useState([
    { id: 1, name: "TCS", role: "React Developer", students: 12 },
    { id: 2, name: "Infosys", role: "Node Developer", students: 8 },
    { id: 3, name: "Wipro", role: "Frontend Developer", students: 15 },
  ]);

  const currentPath = location.pathname;

  const isActive = (path) => currentPath === path;

  return (
    <div className="sa-layout">
      <aside className="sa-sidebar">
        <div className="sa-brand">
          <div className="sa-logo">
            <ShieldCheck size={30} />
          </div>
          <div>
            <h3>InstituteOS</h3>
            <p>Super Admin</p>
          </div>
        </div>

        <div className="sa-menu">
          <button
            className={isActive("/superadmin") ? "active" : ""}
            onClick={() => navigate("/superadmin")}
          >
            <LayoutDashboard size={20} />
            Dashboard
          </button>

          <button
            className={isActive("/superadmin/institutes") ? "active" : ""}
            onClick={() => navigate("/superadmin/institutes")}
          >
            <Building2 size={20} />
            Institutes
          </button>

          <button
            className={isActive("/superadmin/courses") ? "active" : ""}
            onClick={() => navigate("/superadmin/courses")}
          >
            <BookOpen size={20} />
            Courses
          </button>

          <button
            className={isActive("/superadmin/companies") ? "active" : ""}
            onClick={() => navigate("/superadmin/companies")}
          >
            <BriefcaseBusiness size={20} />
            Companies
          </button>
        </div>

        <div className="sa-health">
          <p>System Health</p>
          <h2>98.4%</h2>
          <span>All modules are running properly.</span>
        </div>

        <button className="sa-logout" onClick={() => navigate("/login")}>
          <LogOut size={18} />
          Logout
        </button>
      </aside>

      <main className="sa-main">
        {currentPath === "/superadmin" && (
          <Dashboard
            institutes={institutes}
            courses={courses}
            companies={companies}
            navigate={navigate}
          />
        )}

        {currentPath === "/superadmin/institutes" && (
          <Institutes
            institutes={institutes}
            setInstitutes={setInstitutes}
            courses={courses}
          />
        )}

        {currentPath === "/superadmin/courses" && (
          <Courses courses={courses} setCourses={setCourses} />
        )}

        {currentPath === "/superadmin/companies" && (
          <Companies companies={companies} setCompanies={setCompanies} />
        )}
      </main>
    </div>
  );
}

export default Supper_admin;